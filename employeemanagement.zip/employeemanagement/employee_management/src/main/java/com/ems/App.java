package com.ems;

/**
 * Hello world!
 *
 */
public class App 
{
	
		public static void main(String[] args) {
			
			Menu  m = new Menu(); 
			m.login();
			m.mainMenu();
		}
}
