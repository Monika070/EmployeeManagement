package com.ems.dao;

public class GuestDao {

}
